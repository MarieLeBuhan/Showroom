<!--Marie LE BUHAN
  Date: de janvier à avril 2021 
  Thème: Office de tourisme de Brest
  Description: Cette page affiche dans un tableau différentes sélections.
-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Office de tourisme Brest</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" />
    <link rel="stylesheet" href="css/all.min.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="slick/slick.css"/>    
    <link rel="stylesheet" href="slick/slick-theme.css"/>    
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/templatemo-dream-pulse.css" />
  </head>
  <body>
    <main class="container-fluid">
      <div class="row">        
        <nav id="tmSidebar" class="tm-bg-black-transparent tm-sidebar">
            <button class="navbar-toggler" type="button" aria-label="Toggle navigation">
              <i class="fas fa-bars"></i>
            </button>
            <div class="tm-sidebar-sticky">
              <div class="tm-brand-box">
                <div class="tm-double-border-1">
                  <div class="tm-double-border-2">
                    <h1 class="tm-brand text-uppercase">OFFICE DE TOURISME BREST</h1>
                  </div>
                </div>
              </div>
              <ul class="nav flex-column text-uppercase text-right tm-main-nav">
                <li class="nav-item">
                  <a href="index.php" class="nav-link">
                    <span class="d-inline-block mr-3">Accueil</span> 
                    <span class="d-inline-block tm-white-rect"></span>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="inscription.php" class="nav-link">
                    <span class="d-inline-block mr-3">Inscription</span> 
                    <span class="d-inline-block tm-white-rect"></span>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="session.php" class="nav-link">
                    <span class="d-inline-block mr-3">Connexion</span> 
                    <span class="d-inline-block tm-white-rect"></span>
                  </a>
                </li>
              </ul>
              <ul class="nav flex-row tm-social-links">
                <li class="nav-item">
                  <a href="https://facebook.com" class="nav-link tm-social-link">
                    <i class="fab fa-facebook-f"></i>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="https://twitter.com" class="nav-link tm-social-link">
                    <i class="fab fa-twitter"></i>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="https://dribbble.com" class="nav-link tm-social-link">
                    <i class="fab fa-dribbble"></i>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="https://linkedin.com" class="nav-link tm-social-link">
                    <i class="fab fa-linkedin-in"></i>
                  </a>
                </li>
              </ul>
              <footer class="text-center text-white small">
                <p class="mb--0 mb-2">Copyright 2020 Office de tourisme Brest</p>
                <p class="mb-0">Design:
                  <a rel="nofollow" href="https://templatemo.com" class="tm-footer-link">Marie Le Buhan</a>
                </p>
              </footer>
            </div>
          </nav>
          <main role="main" class="ml-sm-auto col-12">
            <div class="parallax-window" data-parallax="scroll" data-image-src="img/GR34.jpg">
              <div class="tm-section-wrap">
                <section id="intro" class="tm-section">
                  <div class="tm-bg-white-transparent tm-intro"> <b>
                    <h2 class="tm-section-title mb-5 text-uppercase tm-color-primary"><b>Nos sélections</b></h2>
                    <p class="tm-color-white"></b>
                    </p>
                    <p class="mb-0 tm-color-white">
                    </p>
						      </div>              
                </section>
              </div>            
            </div>
            <div class="tm-section-wrap bg-white">
              <section id="work3" class="row tm-section">
                <div class="col-12">
                  <div class="w-100 tm-double-border-1 tm-border-gray">
                    <div class="tm-double-border-2 tm-border-gray tm-box-pad">
                      <div class="tm-gallery-wrap">
                        <h2>Choisissez votre sélection:</h2>
                        <?php 
                          $mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
                          if ($mysqli->connect_errno) 
                          {     
                            echo "Error: Problème de connexion à la BDD \n";
                            echo "Errno: " . $mysqli->connect_errno . "\n";
                            echo "Error: " . $mysqli->connect_error . "\n";
                            exit();
                          }
                          if (!$mysqli->set_charset("utf8"))
                          {
                            printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
                            exit();
                          }
                          //echo ("Connexion BDD réussie !<br />");

                          //sélectionne tous les éléments de sélections
                          $requete="SELECT * FROM t_selection_selec;";
                          //echo($requete);
                          $result = $mysqli->query($requete);
                          if ($result == false) 
                          { 
                            echo "Error: La requête a echoué \n";
                            echo "Query: " . $requete . "\n";
                            echo "Errno: " . $mysqli->errno . "\n";
                            echo "Error: " . $mysqli->error . "\n";
                            exit();
                          }
                          else 
                          {
                            echo ("<table class='table-bordered'>");
                            echo("<tr>"); 
                            echo("<th>"); echo("Titre"); echo("</th>");
                            echo("<th>"); echo("Description"); echo("</th>");
                            echo("<th>"); echo("Auteur"); echo("</th>");
                            echo("<th>");echo("Liens"); echo("</th>");
                            echo("</tr>");
                            while ($selec = $result->fetch_assoc()) 
                            {
                              echo("<tr>");
                              echo ("<td class='marie'>"); echo ($selec['selec_intitule']); echo ("</td>");
                              echo ("<td class='marie'>"); echo($selec['selec_texte']);echo ("</td>");
                              echo ("<td class='marie'>"); echo($selec['cpt_pseudo']);echo ("</td>");

                              //récupère le premier élément associé à la sélection choisi
                              $req="SELECT elmt_numero FROM tj_rassemble_rbl where selec_numero=" . $selec['selec_numero']. " AND elmt_numero>0 LIMIT 1;";
                              //echo($req);
                              $rslt = $mysqli->query($req);
                              if ($rslt == false) 
                              { 
                                echo "Error: La requête a echoué \n";
                                echo "Query: " . $req . "\n";
                                echo "Errno: " . $mysqli->errno . "\n";
                                echo "Error: " . $mysqli->error . "\n";
                               exit();
                              }else {
                                $elmt_numero = $rslt->fetch_assoc();
                                echo ("<td class='marie'>"); 
                                echo"<a href='./affichageselection.php?selec_numero=". $selec['selec_numero'] ."&elmt_numero=". $elmt_numero['elmt_numero'] ."'> <img src='img/oeil2.jpg'> </a>"; 
                                echo ("</td>");
                              }
                              echo ("</tr>");
                            }
                            echo ("</table>");
                          }
                          $mysqli->close();
                        ?> 
                      </div>                        
                    </div>                  
                  </div>     
                </div>         
              </section>
            </div>
          </div>
        </main>
      </div>
    </main>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="slick/slick.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/templatemo-scripts.js"></script>
  </body>
</html>