<!--Marie LE BUHAN
  Date: janvier 2021
  Thème: Office de tourisme de Brest
  Description: Cette page permet d'afficher les différentes sélections avec les éléments qu'elles continnent.
  Puis, à la fin, il y a un formulaire permettant de supprimer un élément d'une sélection.
-->
<?php
  session_start();
  if(!isset($_SESSION['cpt_pseudo']) || !isset($_SESSION['pfl_statut']) ){
    header("Location:session.php");
    exit();
  } 
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Office de tourisme Brest</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" />
    <link rel="stylesheet" href="css/all.min.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="slick/slick.css"/>    
    <link rel="stylesheet" href="slick/slick-theme.css"/>    
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/templatemo-dream-pulse.css" />
  </head>
  <body>
    <main class="container-fluid">
      <div class="row">        
        <nav id="tmSidebar" class="tm-bg-black-transparent tm-sidebar">
          <button class="navbar-toggler" type="button" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
          </button>
          <div class="tm-sidebar-sticky">
            <div class="tm-brand-box">
              <div class="tm-double-border-1">
                <div class="tm-double-border-2">
                  <h1 class="tm-brand text-uppercase">OFFICE DE TOURISME BREST</h1>
                </div>
              </div>
            </div>
            <ul class="nav flex-column text-uppercase text-right tm-main-nav">
              <li class="nav-item">
                <a href="admin_accueil.php" class="nav-link">
                  <span class="d-inline-block mr-3">Accueil & profil(s)</span> 
                  <span class="d-inline-block tm-white-rect"></span>
                </a>
              </li>
              <li class="nav-item">
                <a href="admin_actualites.php" class="nav-link">
                  <span class="d-inline-block mr-3">Gestion des actualités</span> 
                  <span class="d-inline-block tm-white-rect"></span>
                </a>
              </li>
              <li class="nav-item">
                <a href="deconnexion.php">
                  </br><center><input type='submit' value='DECONNEXION'></center>
                </a>
              </li>
            </ul>
            <ul class="nav flex-row tm-social-links">
              <li class="nav-item">
                <a href="https://facebook.com" class="nav-link tm-social-link">
                  <i class="fab fa-facebook-f"></i>
                </a>
              </li>
              <li class="nav-item">
                <a href="https://twitter.com" class="nav-link tm-social-link">
                  <i class="fab fa-twitter"></i>
                </a>
              </li>
              <li class="nav-item">
                <a href="https://dribbble.com" class="nav-link tm-social-link">
                  <i class="fab fa-dribbble"></i>
                </a>
              </li>
              <li class="nav-item">
                <a href="https://linkedin.com" class="nav-link tm-social-link">
                  <i class="fab fa-linkedin-in"></i>
                </a>
              </li>
            </ul>
            <footer class="text-center text-white small">
              <p class="mb--0 mb-2">Copyright 2020 Office de tourisme Brest</p>
              <p class="mb-0">Design:
                <a rel="nofollow" href="https://templatemo.com" class="tm-footer-link">Marie Le Buhan</a>
              </p>
            </footer>
          </div>
        </nav>
        <main role="main" class="ml-sm-auto col-12">
          <div class="parallax-window" data-parallax="scroll" color="brown">
            <div class="tm-section-wrap">
              <section id="intro" class="tm-section">
                <div class="tm-bg-white-transparent tm-intro"> <b>
                  <h1 class="tm-section-title mb-5 text-uppercase tm-color-white"><b><center>Espace administration</center></b></h1>
                  <p class="tm-color-white"></b></p>
                  <p class="mb-0 tm-color-white"></p>    
                </div>              
              </section>
            </div>            
          </div>
          <div class="tm-section-wrap bg-white">
            <section id="work3" class="row tm-section">
              <div class="col-12">
                <div class="w-100 tm-double-border-1 tm-border-gray">
                  <div class="tm-double-border-2 tm-border-gray tm-box-pad">
                    <div class="tm-gallery-wrap">
                      <p> </p>
                      <h2>Gestion des sélections</h2>
                      <?php
                        $id=$_SESSION['cpt_pseudo'];
                        $mdp=$_SESSION['pfl_statut'];
                        
                        $mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
                        if ($mysqli->connect_errno){
                          echo "Error: Problème de connexion à la BDD \n";
                          echo "Errno: " . $mysqli->connect_errno . "\n";
                          echo "Error: " . $mysqli->connect_error . "\n";
                          exit();
                        }
                        //echo ("Connexion BDD réussie! <br/>");
                        if (!$mysqli->set_charset("utf8")) {
                          printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
                          exit();
                        }
                        // récupère le pseudo, l'id de la sélection et son nom
                        $sql="SELECT selec_numero, selec_intitule, cpt_pseudo from t_selection_selec;";
                        //echo($sql);
                        $resultat = $mysqli->query($sql);
                        if ($resultat == false) {
                          echo "Error: La requête du compte a échoué <br/>";
                          echo "Query: " . $sql . "<br/>";
                          echo "Errno: " . $mysqli->errno . "<br/>";
                          echo "Error: " . $mysqli->error . "<br/>";
                          exit();
                        } else {
                          while($sel=$resultat->fetch_assoc()){
                            echo("</br><h3>".$sel['selec_intitule']." ,".$sel['cpt_pseudo']."</h3>");
                            //récpère l'id de l'élément, le nom de l'élément et son état pour une sélection donnée
                            $sql1="SELECT r.elmt_numero, e.elmt_intitule, e.elmt_etat from tj_rassemble_rbl as r join t_element_elmt as e using (elmt_numero) where r.selec_numero='".$sel['selec_numero']."';";
                            //echo($sql1);
                            $resultat1 = $mysqli->query($sql1);
                            if ($resultat1 == false) {
                              echo "Error: La requête du compte a échoué <br/>";
                              echo "Query: " . $sql1 . "<br/>";
                              echo "Errno: " . $mysqli->errno . "<br/>";
                              echo "Error: " . $mysqli->error . "<br/>";
                              exit();
                            } else {
                              echo("<table>");
                              while($elmt=$resultat1->fetch_assoc()){
                                echo("<tr>");
                                echo("<td class='marie'>".$elmt['elmt_intitule']." </td>");
                                echo("<td class='marie'>".$elmt['elmt_etat']."</td>");
                                echo("<tr>");
                              }
                              echo("</table>");
                            } 
                          }

                        }
                        //ré-exécute la requête pour récupérer le nom des sélection pour la première liste déroulante
                        $R=$mysqli->query($sql);

                        echo("</br>Sélectionner une sélection</br>");
                        echo("<form action='adminsel_action.php' method='post'>");

                        echo("<select name='selection'>");
                        while($selec= $R->fetch_assoc()){
                          echo("<option value=".$selec['selec_numero'].">". $selec['selec_intitule'] ."</option>");
                          $idsel=$selec['selec_numero'];
                        }
                        echo("</select>");

                        //récupère l'id, le nom, et l'état de TOUS les éléments
                        $sql2="SELECT r.elmt_numero, e.elmt_intitule, e.elmt_etat from tj_rassemble_rbl as r join t_element_elmt as e using (elmt_numero);";
                        //echo($sql2)
                        $resultat2=$mysqli->query($sql2);
                        if($resultat2==false){
                          echo "Error: La requête a échoué \n";
                          echo "Query: " . $sql2 . "\n";
                          echo "Errno: " . $mysqli->errno . "\n";
                          echo "Error: " . $mysqli->error . "\n";
                        }else{
                          echo("</br>Sélectionner une activité a supprimer</br>");
                          echo("<select name='element'>");
                          while($el= $resultat2->fetch_assoc()){
                              echo("<option value=".$el['elmt_numero'].">". $el['elmt_intitule'] ."</option>");
                          } 
                          echo("</select>");
                          echo(" <p><input type='submit' value='Valider'></p>");
                          echo("</form>");
                          echo("<p>Attention! Pour que la suppression fonctionne, l'élément doit faire partie de la sélection indiquée ci-dessus!</p>");
                        }
                        $mysqli->close();
                      ?>
                    </div>                        
                  </div>                  
                </div>     
              </div>         
            </section>
          </div>
        </main>        
      </div>
    </main>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="slick/slick.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/templatemo-scripts.js"></script>
  </body>
</html>