<!--Marie LE BUHAN
  Date: janvier 2021
  Thème: Office de tourisme de Brest
  Description: Lorsque l'utilisateur appuie sur le bouton "déconnexion" dans le menu, 
  il est redirigé vers cette page qui, s'il n'y a pas eus de problème avec $_SESSION auparavant, 
  libère les variables $_SESSIOn et ferme la session.
-->
<?php
  session_start();
  if(!isset($_SESSION['cpt_pseudo']) || !isset($_SESSION['pfl_statut']) ){
    header("Location:session.php");
    exit();
  } 
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  </head>
  <body>
  	<?php
  		unset($_SESSION['cpt_pseudo']);
  		unset($_SESSION['pfl_statut']);
  		session_destroy();
  		header("Location:session.php");
  	?>
  <head>
  </body>
 </html>