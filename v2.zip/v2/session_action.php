<!--Marie LE BUHAN
  Date: janvier 2021
  Thème: Office de tourisme de Brest
  Description: Cette page ouvre une session et récupère par $_POST l'id et le mot de passe du compte.
  Puis, à partir de ces infos, cette page va récupérer le pseudo et le statut de l'utilisateur qui vont 
  être insérés dans des variables $_SESSION.
-->
<!DOCTYPE html>
 <html>
  <head>
  </head>
  <body>
    <?php
      session_start();
      if($_POST['pseudo'] && $_POST['mdp']){
        $id=htmlspecialchars(addslashes($_POST['pseudo']));
        $mdp=htmlspecialchars(addslashes($_POST['mdp'])); 
      }else{
        echo "ERREUR: FORMULAIRE INCOMPLET!";
        echo'<a href="session.php"> Retour vers la page de connexion </a>';
        exit();
      }
      $mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
      if ($mysqli->connect_errno){
        echo "Error: Problème de connexion à la BDD \n";
        echo "Errno: " . $mysqli->connect_errno . "\n";
        echo "Error: " . $mysqli->connect_error . "\n";
        exit();
      }
      echo ("Connexion BDD réussie! <br/>");
      if (!$mysqli->set_charset("utf8")) {
        printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
        exit();
      }
      //recupère le pseudo et le statut de la personne
      $sql="SELECT pfl_statut, cpt_pseudo FROM t_profil_pfl JOIN t_compte_cpt USING (cpt_pseudo) WHERE cpt_pseudo='".$id."' AND cpt_mdp=MD5('".$mdp."') AND pfl_validite='A';";
      echo($sql);
      $resultat = $mysqli->query($sql); 
      if ($resultat == false){
        echo "Error: La requête du compte a échoué <br/>";
        echo "Query: " . $sql . "<br/>";
        echo "Errno: " . $mysqli->errno . "<br/>";
        echo "Error: " . $mysqli->error . "<br/>";
        exit();
      } else {
        if($resultat->num_rows == 1) {
          $profil = $resultat->fetch_assoc();
          $_SESSION['cpt_pseudo']=$profil['cpt_pseudo'];
          $_SESSION['pfl_statut']=$profil['pfl_statut'];
          header("Location:admin_accueil.php");
          echo"<br /><a href=\"./admin_accueil.php\">Accueil admin</a>";
          echo($_SESSION['cpt_pseudo']);
          echo($_SESSION['pfl_statut']);
        }else{
          header("Refresh:5;url=session.php");
          echo "</br>Pseudo ou mot de passe incorrect(s) ou compte inconnu!";
          echo "<br /><a href=\"./session.php\">Cliquez ici pour réafficher le formulaire</a>";
        }
      } 
      $mysqli->close();
    ?>
  </body>
</html>