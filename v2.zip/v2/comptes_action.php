<!--Marie LE BUHAN
  Date: janvier 2021
  Thème: Office de tourisme de Brest
  Description: Cette page permet de récupérer le pseudo du profil a activer ou désactiver via $_POST.
  Puis, désactive le compte s'il est activé ou l'active s'il est désactivé.
-->
<?php
  session_start();
  if(!isset($_SESSION['cpt_pseudo']) || !isset($_SESSION['pfl_statut']) ){
    header("Location:session.php");
    exit();
  } 
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  </head>
  <body>
    <p>Rentré!</p>
    <?php echo ($_POST['selection']); 
    ?> 
    <?php
      if($_POST['selection']){
        echo($_POST['selection']);
        $pseudo=$_POST['selection'];
      }

      $mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
      if ($mysqli->connect_errno){
        echo "Error: Problème de connexion à la BDD \n";
        echo "Errno: " . $mysqli->connect_errno . "\n";
        echo "Error: " . $mysqli->connect_error . "\n";
        exit();
      }
      echo ("Connexion BDD réussie! <br/>");
      if (!$mysqli->set_charset("utf8")) {
        printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
        exit();
      }
      //récupère la validité du profil
      $sql="SELECT pfl_validite from t_profil_pfl where cpt_pseudo='".$pseudo."';";
      $resultat = $mysqli->query($sql);
      if ($resultat == false) {
        echo "Error: La requête du compte a échoué <br/>";
        echo "Query: " . $sql . "<br/>";
        echo "Errno: " . $mysqli->errno . "<br/>";
        echo "Error: " . $mysqli->error . "<br/>";
        exit();
      } else {
        $validite=$resultat->fetch_assoc();
        if ($validite['pfl_validite']=='A'){
          //si la personne a un compte actif, la modification suivante le désactive
          $req="UPDATE t_profil_pfl set pfl_validite='D' where cpt_pseudo='".$pseudo."';";
          //echo($req);
          $rslt = $mysqli->query($req);
          if ($rslt == false) {
            echo "Error: La requête du compte a échoué <br/>";
            echo "Query: " . $req . "<br/>";
            echo "Errno: " . $mysqli->errno . "<br/>";
            echo "Error: " . $mysqli->error . "<br/>";
            exit();
          }
        }else if($validite['pfl_validite']=='D'){
          //si la personne a un compte désactivé, la modification suivante l'active'
          $req1="UPDATE t_profil_pfl set pfl_validite='A' where cpt_pseudo='".$pseudo."';";
          //echo($req1);
          $rslt1 = $mysqli->query($req1);
          if ($rslt1 == false) {
            echo "Error: La requête du compte a échoué <br/>";
            echo "Query: " . $req1 . "<br/>";
            echo "Errno: " . $mysqli->errno . "<br/>";
            echo "Error: " . $mysqli->error . "<br/>";
            exit();
          }
        }
      }
      header("Location:admin_accueil.php");
      echo("<br /><a href=\"./admin_accueil.php\">Retour à l'accueil de l'administration</a>");
      $mysqli->close();
    ?> 
  </body>
</html>