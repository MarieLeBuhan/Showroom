<!--Marie LE BUHAN
  Date: janvier 2021
  Thème: Office de tourisme de Brest
  Description: Cette page vérifie tout d'abord, que la sélection et l'élement choisit sont bien en relation.
  Puis, supprime cette relation ,si elle existe.
-->
<?php
  session_start();
  if(!isset($_SESSION['cpt_pseudo']) || !isset($_SESSION['pfl_statut']) ){
    header("Location:session.php");
    exit();
  } 
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		
	</head>
	<body>
		<p>Rentré!</p>
    	<?php echo ($_POST['selection']); ?>
    	<?php echo ($_POST['element']); ?> 
    	<?php
     		if($_POST['selection']){
        		echo($_POST['selection']);
        		$selection=$_POST['selection'];
      	}
      	if($_POST['element']){
        	echo($_POST['element']);
        	$element=$_POST['element'];
      	}
        $mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
        if ($mysqli->connect_errno){
          echo "Error: Problème de connexion à la BDD \n";
          echo "Errno: " . $mysqli->connect_errno . "\n";
          echo "Error: " . $mysqli->connect_error . "\n";
          exit();
        }
        echo ("Connexion BDD réussie! <br/>");
        if (!$mysqli->set_charset("utf8")) {
          printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
          exit();
        }
        //test si pour un numero de sélection donné et pour un numéro d'élément donné, s'il existe bien un lien
        $sql="SELECT * from tj_rassemble_rbl where selec_numero='".$selection."' and elmt_numero='".$element."';";
        //echo($sql);
        $resultat = $mysqli->query($sql);
        if ($resultat == false) {
          echo "Error: La requête a échoué <br/>";
          echo "Query: " . $sql . "<br/>";
          echo "Errno: " . $mysqli->errno . "<br/>";
          echo "Error: " . $mysqli->error . "<br/>";
          exit();
        } else {
          $ligne=$resultat->num_rows;
          if($ligne==0){
            echo("ERREUR! L'élément choisi n'appartient pas à la sélection sélectionnée!");
            header("Location:admin_selection.php");
          } else{
            //s'il y a bien un lien, on le supprime
            $req_suppr_tj="DELETE from tj_rassemble_rbl where selec_numero='".$selection."' and elmt_numero='".$element."';";
            //echo($req_suppr-tj);
            $resultat1 = $mysqli->query($req_suppr_tj);
            if ($resultat1 == false) {
              echo "Error: La requête du compte a échoué <br/>";
              echo "Query: " . $req_suppr_tj . "<br/>";
              echo "Errno: " . $mysqli->errno . "<br/>";
              echo "Error: " . $mysqli->error . "<br/>";
              exit();
            } else {
                header("Location:admin_selection.php");
            }
          }
        }
        $mysqli->close();
      ?>
	</body>
</html>