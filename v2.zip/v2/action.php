<!--Marie LE BUHAN
  Date: de janvier à avril 2021 
  Thème: Office de tourisme de Brest
  Description: Cette page récupère les données du formulaire via $_POST en utilisant htmlspecialchars et addslashes. 
  Après la page vérifie que tous les champs soient bien rempli, puis, 
  si le mot de passe et la confirmation du mot de passe sont bien identiques.
  Ensuite, on fait l'insertion du compte, si ça ne s'est pas bien passé on renvoi vers la page précédente,
  sinon, on insert le profil, si ça ne se passe pas bien, on supprime le compte et retourne sur la page précédente,
  sinon, l'inscription s'est bien passée et l'utilisateur sera redirigé automatiquement vers inscription.php .
-->
<!DOCTYPE html>
<html lang="en">
  <head>
  </head>
  <body>
<!--    <?php echo htmlspecialchars($_POST['pseudo']); ?>
    <?php echo htmlspecialchars($_POST['mdp']); ?>
    <?php echo htmlspecialchars($_POST['mdp1']); ?>
    <?php echo htmlspecialchars($_POST['nom']); ?>
    <?php echo htmlspecialchars($_POST['prenom']); ?>
    <?php echo htmlspecialchars($_POST['email']); ?>
-->
    <?php
      //htmlspecalchars et addslashes permettent aux caractères spéciaux d'être entrés dans les champs et évitent que la sécurité soit forcée
      if($_POST['pseudo'] && $_POST['mdp'] && $_POST['mdp1'] && $_POST['nom'] && $_POST['prenom'] && $_POST['email'] ){
        $id=htmlspecialchars(addslashes($_POST['pseudo']));
        $mdp=htmlspecialchars(addslashes($_POST['mdp']));
        $mdp1=htmlspecialchars(addslashes($_POST['mdp1']));
        $nom=htmlspecialchars(addslashes($_POST['nom']));
        $prenom=htmlspecialchars(addslashes($_POST['prenom']));
        $email=htmlspecialchars(addslashes($_POST['email']));
      }else{
        header("Refresh:5;url=inscription.php");
        echo ("</br>ERREUR: FORMULAIRE INCOMPLET! Vous allez être directement redirigé vers la page précédente. Sinon:");
        echo('<a href="inscription.php"> Retour vers le formulaire </a>');
        exit();
      }
      $mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
      if ($mysqli->connect_errno){
        echo "Error: Problème de connexion à la BDD \n";
        echo "Errno: " . $mysqli->connect_errno . "\n";
        echo "Error: " . $mysqli->connect_error . "\n";
        exit();
      }
      //echo ("Connexion BDD réussie! <br/>");
      if (!$mysqli->set_charset("utf8")) {
        printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
        exit();
      }
      //Vérifie si le mot de passe et la confirmation de mot de passe sont identiques
      if(strcmp($mdp,$mdp1)!=0){
        header("Refresh:5;url=inscription.php");
        echo "ERREUR: la confirmation du mot de passe n'est pas correct! Vous allez être directement redirigé vers la page précédente. Sinon:";
        echo'<a href="inscription.php"> Retour vers le formulaire </a>';
        exit();
      }

      //Requête permettent l'insertion d'un compte
      $sql="INSERT INTO t_compte_cpt VALUES('" .$id. "',MD5('" .$mdp. "'));";
      $result = $mysqli->query($sql); 
      //echo($sql);
      if ($result == false) {
        echo "Error: La requête de la création d'un compte a échoué <br/>";
        echo "Query: " . $sql . "<br/>";
        echo "Errno: " . $mysqli->errno . "<br/>";
        echo "Error: " . $mysqli->error . "<br/>";
        echo'<a href="inscription.php"> Retour vers le formulaire </a>';
        exit();
      }else{
        echo ("</br>Inscription dans le compte réussie!</br>");
        $sql1="INSERT INTO t_profil_pfl VALUES('" .$nom. "','" .$prenom. "','" .$email. "','D','R',curdate(),'" .$id. "');";
        $result1 = $mysqli->query($sql1);
        //echo($sql1);
        if($result1 == false){
          echo "Error: La requête de la création d'un profil a échoué \n";
          echo "Query: " . $sql1 . "\n";
          echo "Errno: " . $mysqli->errno . "\n";
          echo "Error: " . $mysqli->error . "\n";
          //Si l'ajout du profil a échoué, on supprime le nouveau compte
          $sql2="DELETE FROM t_compte_cpt WHERE cpt_pseudo='$id';";
          $result2 = $mysqli->query($sql2); 
          //echo($sql2);
          if($result2==false){
            echo "Error: La requête de la supression du compte a échoué \n";
            echo "Query: " . $sql2 . "\n";
            echo "Errno: " . $mysqli->errno . "\n";
            echo "Error: " . $mysqli->error . "\n";
            echo("Réessayez-en changeant de pseudo");
            echo('<a href="inscription.php"> Retour vers le formulaire </a>');
          } else{
            header("Refresh:5;url=inscription.php");
            echo("La supression du compte a réussi.</br>");
            echo('<a href="inscription.php"> Retour vers le formulaire </a>');
            exit();
          }         
        }else{
          header("Refresh:5;url=inscription.php");
          echo ("Inscription dans le profil réussie! </br>Vous allez être redirigé, sinon:");
          echo('<a href="inscription.php"> Retour vers le formulaire </a>');
        }
      }
      $mysqli->close();
    ?>
  </body>
</html>