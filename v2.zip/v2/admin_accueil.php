<!--Marie LE BUHAN
  Date: janvier 2021
  Thème: Office de tourisme de Brest
  Description: Cette page va souhaiter la bienvenue à son utilisateur, puis, elle va afficher 
  son prénom, son nom ,son mail et préciser si son utilisateur est responsable ou administrateur.
  De plus, si l'utilisateur est un administrateur, le nombre de comptes lui sera affiché, ainsi, 
  qu'un tableau avec toutes les informations sur les profils de tous les utilisateurs.
  Le formulaire final permet d'activer et de désactiver un compte, toujours avec la méthode de POST.
-->
<?php
  session_start();
  if(!isset($_SESSION['cpt_pseudo']) || !isset($_SESSION['pfl_statut']) ) //A COMPLETER pour tester aussi le statut...
  {
    header("Location:session.php");
    exit();
  } 

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Office de tourisme Brest</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" />
    <link rel="stylesheet" href="css/all.min.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="slick/slick.css"/>    
    <link rel="stylesheet" href="slick/slick-theme.css"/>    
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/templatemo-dream-pulse.css" />
  </head>
  <body>
    <main class="container-fluid">
      <div class="row">        
        <nav id="tmSidebar" class="tm-bg-black-transparent tm-sidebar">
          <button class="navbar-toggler" type="button" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
          </button>
          <div class="tm-sidebar-sticky">
            <div class="tm-brand-box">
              <div class="tm-double-border-1">
                <div class="tm-double-border-2">
                  <h1 class="tm-brand text-uppercase">OFFICE DE TOURISME BREST</h1> 
                </div>
              </div>
            </div>
            <ul class="nav flex-column text-uppercase text-right tm-main-nav">
            	<li class="nav-item">
                <a href="admin_selection.php" class="nav-link">
                  <span class="d-inline-block mr-3">Gestion des sélections</span> 
                  <span class="d-inline-block tm-white-rect"></span>
                </a>
              </li>
              <li class="nav-item">
                <a href="admin_actualites.php" class="nav-link">
                  <span class="d-inline-block mr-3">Gestion des actualités</span> 
                  <span class="d-inline-block tm-white-rect"></span>
                </a>
              </li>
              <li class="nav-item">
                <a href="deconnexion.php">
                  </br><center><input type='submit' value='DECONNEXION'>
                  </center>
                </a>          
              </li>
            </ul>
            <ul class="nav flex-row tm-social-links">
              <li class="nav-item">
                <a href="https://facebook.com" class="nav-link tm-social-link">
                  <i class="fab fa-facebook-f"></i>
                </a>
              </li>
              <li class="nav-item">
                <a href="https://twitter.com" class="nav-link tm-social-link">
                  <i class="fab fa-twitter"></i>
                </a>
              </li>
              <li class="nav-item">
                <a href="https://dribbble.com" class="nav-link tm-social-link">
                  <i class="fab fa-dribbble"></i>
                </a>
              </li>
              <li class="nav-item">
                <a href="https://linkedin.com" class="nav-link tm-social-link">
                  <i class="fab fa-linkedin-in"></i>
                </a>
              </li>
            </ul>
            <footer class="text-center text-white small">
              <p class="mb--0 mb-2">Copyright 2020 Office de tourisme Brest</p>
              <p class="mb-0">Design:
                <a rel="nofollow" href="https://templatemo.com" class="tm-footer-link">Marie Le Buhan</a>
              </p>
            </footer>
          </div>
        </nav>
        <main role="main" class="ml-sm-auto col-12">
          <div class="parallax-window" data-parallax="scroll" color="brown">
            <div class="tm-section-wrap">
              <section id="intro" class="tm-section">
                <div class="tm-bg-white-transparent tm-intro"> <b>
                  <h2 class="tm-section-title mb-5 text-uppercase tm-color-white"><b><center>Espace administration</center></b></h2>
                  <p class="tm-color-white"></b> </p>
                  <p class="mb-0 tm-color-white"></p>
					      </div>              
              </section>
            </div>            
          </div>
          <div class="tm-section-wrap bg-white">
            <section id="work3" class="row tm-section">
              <div class="col-12">
                <div class="w-100 tm-double-border-1 tm-border-gray">
                  <div class="tm-double-border-2 tm-border-gray tm-box-pad">
                    <div class="tm-gallery-wrap">
                      <p> </p>
                      <?php
                        $id=$_SESSION['cpt_pseudo'];
                        $mdp=$_SESSION['pfl_statut'];
                        
                        $mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
                        if ($mysqli->connect_errno){
                          echo "Error: Problème de connexion à la BDD \n";
                          echo "Errno: " . $mysqli->connect_errno . "\n";
                          echo "Error: " . $mysqli->connect_error . "\n";
                          exit();
                        }
                        //echo ("Connexion BDD réussie! <br/>");
                        if (!$mysqli->set_charset("utf8")) {
                          printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
                          exit();
                        }
                        //récupère les données du profil de l'utilisateur qui vient de se conneccter
                        $sql="SELECT  p.pfl_nom, p.pfl_prenom, p.pfl_email, p.pfl_validite, p.pfl_statut, p.pfl_date_creation, c.cpt_pseudo from t_compte_cpt as c join t_profil_pfl as p using (cpt_pseudo) where c.cpt_pseudo='".$id."';";
                        //echo($sql);
                        $resultat = $mysqli->query($sql);
                        if ($resultat == false) {
                          echo "Error: La requête du compte a échoué <br/>";
                          echo "Query: " . $sql . "<br/>";
                          echo "Errno: " . $mysqli->errno . "<br/>";
                          echo "Error: " . $mysqli->error . "<br/>";
                          exit();
                        } else {
                          $affich_pfl = $resultat->fetch_assoc();
                          echo("<h2> Bienvenue ". $affich_pfl['pfl_prenom'] . "!</h2></br>");
                          echo("<h3 class='tm-color-black'>Profil</h3>".$affich_pfl['pfl_nom']. " ". $affich_pfl['pfl_prenom']."</br>".$affich_pfl['pfl_email']."</br>");
                          if ($affich_pfl['pfl_statut']=='R'){
                          	echo("Vous êtes un responsable!</br>");	
                          }else{
                          	echo("Vous êtes un administrateur!</br>");
                            //récupère le nombre de profils
                           	$nb_compte="SELECT count(*) as nb_compte from t_compte_cpt;";
                            //echo("$nb_compte");
                          	$rslt=$mysqli->query($nb_compte);
                          	if ($resultat == false) {
                          		echo "Error: La requête du compte a échoué <br/>";
                          		echo "Query: " . $nb_compte . "<br/>";
                          		echo "Errno: " . $mysqli->errno . "<br/>";
                          		echo "Error: " . $mysqli->error . "<br/>";
                            	exit();
                        		} else {
                        			$nb = $rslt->fetch_assoc();
                        			echo "</br>";
                        			echo($nb['nb_compte']." comptes");
                              //récupère les données de tous les profils
                        			$req="SELECT  p.pfl_nom, p.pfl_prenom, p.pfl_email, p.pfl_validite, p.pfl_statut, p.pfl_date_creation, c.cpt_pseudo from t_compte_cpt as c join t_profil_pfl as p using (cpt_pseudo);";
                        			$R=$mysqli->query($req);
                        			if ($R == false) {
                          			echo "Error: La requête du compte a échoué <br/>";
                          			echo "Query: " . $sql . "<br/>";
                          			echo "Errno: " . $mysqli->errno . "<br/>";
                          			echo "Error: " . $mysqli->error . "<br/>";
                            		exit();
                        			} else {
                        				echo ("<table class='table-bordered' >");
                        				echo("<tr>"); 
                        				echo("<th>"); echo("Pseudo"); echo("</th>");
                    				    echo("<th>"); echo("Nom"); echo("</th>");
                                echo("<th>"); echo("Prénom"); echo("</th>");
                        				echo("<th>");echo("Mail"); echo("</th>");
                        				echo("<th>");echo("Validité"); echo("</th>");
                        				echo("<th>");echo("Statut"); echo("</th>");
                        				echo("</tr>");
                        				while($tab = $R->fetch_assoc()){
                        					echo("<tr >");
                        					echo("<td class='marie'>".$tab['cpt_pseudo']."</td>");
                        					echo("<td class='marie'>".$tab['pfl_nom']."</td>");
                        					echo("<td class='marie'>".$tab['pfl_prenom']."</td>");
                        					echo("<td class='marie'>".$tab['pfl_email']."</td>");
                        					echo("<td class='marie'>".$tab['pfl_validite']."</td>");
                        					echo("<td class='marie'>".$tab['pfl_statut']."</td>");
                        					echo("</tr>");
                        				}
                        				echo("</table>");
                                //ré-exécution de la requête permettant de récupérer toutes les données du profil
                      				  $R=$mysqli->query($req);
                        				echo("</br>Sélectionner le compte à activer ou désactiver</br>");
                        				echo("<form action='comptes_action.php' method='post'>");
										            echo("<select name='selection'>");
                        				while($selec= $R->fetch_assoc()){
                        					echo("<option value=".$selec['cpt_pseudo'].">". $selec['cpt_pseudo'] ."</option>");
                        				}
                        				echo("</select>");
                        				echo(" <p><input type='submit' value='Valider'></p>");
                        				echo("</form>");
                          			}
	                            }
                            }
                          }
                        $mysqli->close();
                      ?>
                    </div>                        
                  </div>                  
                </div>     
              </div>         
            </section>
          </div>
        </main>        
      </div>
    </main>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="slick/slick.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/templatemo-scripts.js"></script>
  </body>
</html>