<!--Marie LE BUHAN
  Date: janvier 2021
  Thème: Office de tourisme de Brest
  Description: Cette page récupère via $_POST le titre, la description et l'état de l'actualité à ajouter.
  Puis, insert une nouvelle actualité.
-->
<?php
  session_start();
  if(!isset($_SESSION['cpt_pseudo']) || !isset($_SESSION['pfl_statut']) ){
    header("Location:session.php");
    exit();
  } 
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	</head>
	<body>
		<?php echo htmlspecialchars($_POST['titre']); ?>
		<?php echo htmlspecialchars($_POST['description']); ?>
		<?php echo htmlspecialchars($_POST['etat']); ?>
		<?php
			if($_POST['titre'] && $_POST['description'] && $_POST['etat']){
				echo($_POST['titre']);
				echo($_POST['description']);
				echo($_POST['etat']);
				$titre=htmlspecialchars(addslashes($_POST['titre']));
				$description=htmlspecialchars(addslashes($_POST['description']));
				$etat=htmlspecialchars(addslashes($_POST['etat']));

			}else{
				header("Refresh:5;url=admin_actualites.php");
				echo("Erreur! Formulaire incomplet!");
				echo('<a href="admin_actualites.php"> Retour vers le formulaire </a>');
       			exit();
			}
			$id=$_SESSION['cpt_pseudo'];

			$mysqli = new mysqli('localhost','zle_buhma','upyfla72','zfl2-zle_buhma');
            if ($mysqli->connect_errno){
	            echo "Error: Problème de connexion à la BDD \n";
	            echo "Errno: " . $mysqli->connect_errno . "\n";
	            echo "Error: " . $mysqli->connect_error . "\n";
            exit();
            }
            //echo ("Connexion BDD réussie! <br/>");
            if (!$mysqli->set_charset("utf8")) {
                printf("Pb de chargement du jeu de car. utf8 : %s\n", $mysqli->error);
                exit();
            }
            //insertion d'une actualité
            $sql="INSERT into t_news_new VALUES(NULL,'".$titre."','".$description."',curdate(),'".$etat."', '".$id."');";
            echo($sql);
            $resultat = $mysqli->query($sql);
	        if ($resultat == false) {
                echo "Error: La requête a échoué <br/>";
                echo "Query: " . $sql . "<br/>";
                echo "Errno: " . $mysqli->errno . "<br/>";
                echo "Error: " . $mysqli->error . "<br/>";
                exit();
            } else {
            	header("Location:admin_actualites.php");
            	echo("</br>Insertion réussie!");
            }
		?>
		
	</body>
</html>